﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Threading;

namespace UpdateBootstrapper
{
    class Program
    {
        private const int expectedArgs = 6;

        private static string updateZipPath = "";
        private static string applicationFolderPath = "";
        private static string applicationExePath = "";
        private static int callingProcessId = 0;
        private static string processName = "";
        private static string defaultAppName = "";

        static void Main(string[] args)
        {
            var handle = GetConsoleWindow();
            ShowWindow(handle, SW_HIDE);

            if (args.Length != expectedArgs)
            {
                ShowWindow(handle, SW_SHOW);
                Console.WriteLine($"Invalid number of arguments. Expected {expectedArgs}.\n" +
                "[0] = updateZipPath\n" +
                "[1] = applicationFolderPath\n" +
                "[2] = applicationExePath\n" +
                "[3] = callingProcessId\n" +
                "[4] = callingProcessName\n" +
                "[5] = defaultAppName");

                Console.ReadLine();
                Environment.Exit(0);
            }

            AppDomain.CurrentDomain.ProcessExit += CurrentDomain_ProcessExit;

            updateZipPath = args[0];
            applicationFolderPath = args[1];
            applicationExePath = args[2];
            callingProcessId = int.Parse(args[3]);
            processName = args[4];
            defaultAppName = args[5];

            //Wait for calling process to exit
            Process caller = Process.GetProcessById(callingProcessId);

            if (!caller.HasExited)
            {
                caller.WaitForExit();
            }

            //Check for other instances of calling process and force end them
            Process[] processes = Process.GetProcessesByName(processName);

            if(processes.Length > 0)
            {
                Console.WriteLine($"{processes.Length} instances of \"{processName}\" found, force closing them...");

                foreach(var process in processes)
                {
                    process.Kill();
                }
            }

            //Check for perms
            if (IsDirWriteLocked(applicationExePath))
            {
                ShowWindow(handle, SW_SHOW);
                Console.WriteLine($"\nAccess denied - the updater does not have write access in the current directory. (To fix, try moving the application into a writable directory)\n\n" +
                    $"Update failed.");
                Console.Read();
                return;
            }

            //Wait while exe is locked
            int timeLocked = 0;
            bool lockWarning = false;

            while (IsFileWriteLocked(applicationExePath))
            {
                if(timeLocked >= 5000 && !lockWarning)
                {
                    ShowWindow(handle, SW_SHOW);
                    lockWarning = true;

                    Console.WriteLine("\nThe exe appears to be locked (still in use). Retrying...");
                }

                if(timeLocked >= 10000)
                {
                    Console.WriteLine($"The application exe seems to be in use still, aborting update.");
                    Console.ReadLine();
                    return;
                }

                Thread.Sleep(100);
                timeLocked += 100;
            }

            Console.WriteLine("Start update:");

            try
            {
                using (var zip = ZipFile.OpenRead(updateZipPath))
                {
                    Console.WriteLine("Extracting files...");

                    foreach (var zipEntry in zip.Entries)
                    {
                        if (zipEntry.FullName.Length == 0) continue;
                        if ((zipEntry.FullName[zipEntry.FullName.Length - 1] == Path.DirectorySeparatorChar || zipEntry.FullName[zipEntry.FullName.Length - 1] == Path.AltDirectorySeparatorChar) && string.IsNullOrWhiteSpace(zipEntry.Name)) continue;

                        if(zipEntry.FullName == defaultAppName)
                        {
                            //In the event that the user renamed the .exe file we must rename it to match here
                            zipEntry.ExtractToFile(applicationExePath, true);
                        }
                        else
                        {
                            string pathToExtract = $"{applicationFolderPath}/{zipEntry.FullName}";
                            Directory.CreateDirectory(Path.GetDirectoryName(pathToExtract));
                            zipEntry.ExtractToFile(pathToExtract, true);
                        }
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                ShowWindow(handle, SW_SHOW);
                Console.WriteLine($"\nAccess denied - the updater does not have write access in the current directory. (To fix, try moving the application into a writable directory)\n\n" +
                    $"Update failed.");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                ShowWindow(handle, SW_SHOW);
                Console.WriteLine($"\nUpdate failed: \n" +
                    $"Exception: {ex.Message}\n\n" +
                    $"Update failed.");
                Console.ReadLine();
            }
        }

        private static void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            Finish();
        }

        private static void Finish()
        {
            try
            {
                File.Delete(updateZipPath);
            }
            catch { }

            Process.Start(applicationExePath);

            Environment.Exit(0);
        }

        private static bool IsFileWriteLocked(string path)
        {
            try
            {
                using (FileStream stream = new FileInfo(path).Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {
                    stream.Close();
                }
            }
            catch
            {
                return true;
            }

            return false;
        }

        private static bool IsDirWriteLocked(string path)
        {
            try
            {
                using (FileStream stream = new FileInfo(path).Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {
                    stream.Close();
                }
            }
            catch (UnauthorizedAccessException)
            {
                return true;
            }
            catch
            {
                return false;
            }

            return false;
        }

        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;
    }
}
